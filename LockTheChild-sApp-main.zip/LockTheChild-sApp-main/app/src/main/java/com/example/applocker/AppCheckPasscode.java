package com.example.applocker;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppCheckPasscode extends AppCompatActivity {

    private EditText passcodeEditText;

    private TextView countdownTextView;
    private TextView restrictionCountdownTextView;
    private Button submitButton;

    private Button usePasscode;
    private String packageName;

    private LinearLayout appLockLayout;
    private LinearLayout restictionLayout;

    private CountDownTimer timer;
    private CountDownTimer restrictiontimer;
    private String TAG = "App Locker on CheckerConfiguration";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        overlayManager = new CustomOverlayManager(this);
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        String childName = preferences.getString("child_name", "no_name");




        packageName = getIntent().getStringExtra("packageName");
        Log.e(TAG, "CHILD NAME: "+childName);
        Log.e(TAG, "PROCEED 1");
        setContentView(R.layout.activity_app_check_passcode);
        Log.e(TAG, "PROCEED 2");
        appLockLayout = findViewById(R.id.applockLayout);
        appLockLayout.setVisibility(View.GONE);
        Log.e(TAG, "PROCEED 3");
        restictionLayout = findViewById(R.id.restrictionLayout);
        restictionLayout.setVisibility(View.GONE);
        countdownTextView = findViewById(R.id.countdownTextView);
        Log.e(TAG, "PROCEED FINALLY!");
        submitButton = findViewById(R.id.submitButton);
        db.collection("Children")
                    .document(childName)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot document) {
                            if (document.exists()) {
                                Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                                Long timerFromFirestore = document.getLong("timer");
                                Long restrictionTimeFirestore = document.getLong("isUsingRestrictionTime");
                                Boolean isUsingTimerFromFirestore = document.getBoolean("is_using_timer");
                                Boolean isUsingRestrictionTimeFirestore = restrictionTimeFirestore != 0;

                                passcodeEditText = findViewById(R.id.passcodeEditText);
                                usePasscode = findViewById(R.id.usePasscode);
                                restrictionCountdownTextView = findViewById((R.id.restrictionCountdownTextView));
                                submitButton = findViewById(R.id.submitButton);
                                submitButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        String userEnteredPasscode = passcodeEditText.getText().toString();
                                        String passcode = document.getString("passcode");
                                        assert passcode != null;
                                        checkPasscode(userEnteredPasscode, passcode, childName);
                                    }
                                });



                                if(isUsingTimerFromFirestore != null){
                                    if(isUsingTimerFromFirestore){
                                        Log.e(TAG, "THIS IS USING TIMER");
                                        Boolean limitIsRunning = preferences.getBoolean("running_limit_timer", false);
                                        restictionLayout.setVisibility(View.VISIBLE);
                                        timer = new CountDownTimer(timerFromFirestore * 1000 * 60, 1000) {
                                            @Override
                                            public void onTick(long millisUntilFinished) {
                                                long seconds = millisUntilFinished / 1000;
                                                long minutes = seconds / 60;
                                                seconds = seconds % 60;
                                                countdownTextView.setText(String.format("Time Remaining: %02d:%02d", minutes, seconds));
//                                                    if (seconds <= 20) {
//                                                        runOnUiThread(new Runnable() {
//                                                            @Override
//                                                            public void run() {
//                                                                overlayManager.show("Only 20 seconds left!");
//                                                            }
//                                                        });
//                                                    }

                                                Log.e(TAG, String.format("Time Remaining: %02d:%02d", minutes, seconds));
                                            }
                                            @Override
                                            public void onFinish() {
                                                Log.e(TAG, "onFinish: TIMER IS FINISHED!");
                                                editor.putBoolean(packageName, false);
                                                Object[] array = ((ArrayList<?>) document.get("locked_apps")).toArray();
                                                Log.e(TAG, "onFinish: "+array);
                                                for(Object packageName : array){
                                                    Log.e(TAG, "package done: "+packageName.toString());
                                                    editor.putBoolean(packageName.toString()+"_isRunning",false);
                                                }
//                                                editor.putBoolean(packageName+"_isRunning",false);
                                                editor.putBoolean("running_limit_timer", false);
                                                //After the timer limit, it checks if there is a restriction time set then let the app know
                                                if(isUsingRestrictionTimeFirestore){
                                                    editor.putBoolean(packageName+"_isRestricted", true);
                                                }
                                                // Update Firestore field 'timer' with the new value
                                                DocumentReference docRef = db.collection("Children").document(childName);
                                                docRef.update("timer", 0, "is_using_timer", false)
                                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                            @Override
                                                            public void onSuccess(Void aVoid) {
                                                                Log.d(TAG, "Timer fields updated successfully");
                                                            }
                                                        })
                                                        .addOnFailureListener(new OnFailureListener() {
                                                            @Override
                                                            public void onFailure(@NonNull Exception e) {
                                                                Log.w(TAG, "Error updating timer field", e);
                                                            }
                                                        });
                                                editor.putInt("timerCount",0);
                                                editor.apply();
                                                timer.cancel();
                                                finish();
                                            }
                                        };
                                        if(limitIsRunning){
                                            Log.e(TAG, "limited timer activated!");
                                            finish();
                                            return;

                                        }else{
                                            Object[] array = ((ArrayList<?>) document.get("locked_apps")).toArray();

                                            for(Object packageName : array){
                                                editor.putBoolean(packageName+"_isRunning", true).apply();
                                            }
                                            editor.putBoolean("running_limit_timer", true).apply();
                                            timer.start();
                                        }
                                        }
                                    else{
                                        if(isUsingRestrictionTimeFirestore){
                                            Log.e(TAG, "USING RESTRICTION" );
                                            restictionLayout.setVisibility(View.VISIBLE);
                                            usePasscode.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View view) {
                                                    restictionLayout.setVisibility(View.GONE);
                                                    appLockLayout.setVisibility(View.VISIBLE);
                                                }
                                            });
                                            editor.putBoolean(packageName+"_isRestricted", false).apply();
                                            Boolean appRestricted = preferences.getBoolean(packageName+"_isRestricted", false);
                                            Boolean isRestrictionTimerRunning = preferences.getBoolean("isRestrictionTimerRunning", false);
                                            if (isRestrictionTimerRunning && !appRestricted) {
                                                finish();
                                                return; // If timer is already running, do nothing
                                            }else{
                                                activateRestrictionTimer(restrictionTimeFirestore, childName);
                                            }


                                        }
                                        // restriction time is disabled, use passcode
                                        else{
                                            Log.e(TAG, "USE ONLY PASSCODE!");
                                            restictionLayout.setVisibility(View.GONE);
                                            appLockLayout.setVisibility(View.VISIBLE);
                                        }
                                    }
                                }
                            } else {
                                Log.d(TAG, "No such document");
                            }
                        }
                    });






    }

    private void activateRestrictionTimer(Long timerFromFirestore, String childName){
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isRestrictionTimerRunning", true).apply();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        Log.e(TAG, "activateRestrictionTimer: "+"Timer: "+timerFromFirestore );

        restrictiontimer = new CountDownTimer(timerFromFirestore * 1000 * 60, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {

                    editor.putLong("restrictCountdown", millisUntilFinished).apply();
                    long seconds = millisUntilFinished / 1000;
                    long minutes = seconds / 60;
                    seconds = seconds % 60;
                    restrictionCountdownTextView.setText(String.format("App Restriction Time: %02d:%02d", minutes, seconds));

                    Log.e(TAG, String.format("App Restriction Time: %02d:%02d", minutes, seconds));
                }
                @Override
                public void onFinish() {
                    Log.e(TAG, "onFinish: RESTRICTION TIMER IS FINISHED!");
                    SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    Set<String> lockedAppsSet = new HashSet<>();
                    editor.putBoolean(packageName, true);
                    editor.putBoolean(packageName+"_isRestricted", false);
                    editor.putStringSet("locked_apps", lockedAppsSet);
                    Log.e(TAG, "onFinish: "+packageName+"_isRestricted");
                    editor.apply();
                    Map<String, Object> updates = new HashMap<>();
//                    Set<String> stringSet = preferences.getStringSet("locked_apps", new HashSet<>());
//                    Set<String> updatedStringSet = new HashSet<>(stringSet);
//                    updates.put("locked_apps", updatedStringSet.remove(packageName));
                    updates.put("isUsingRestrictionTime", 0);

                    // Update Firestore field 'isUsingRestrictionTime' with the new value
                    DocumentReference docRef = db.collection("Children").document(childName);
                    docRef.update(updates)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Log.d(TAG, "isUsingRestrictionTime field updated successfully");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Log.w(TAG, "Error updating timer field", e);
                                }
                            });
                    restrictiontimer.cancel();
                    editor.putBoolean("isRestrictionTimerRunning", false).apply();
                    finish();
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            };
        restrictiontimer.start();


    }

    private void checkPasscode(String userEnteredPasscode, String savedPasscode, String childName) {
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        Set<String> stringSet = preferences.getStringSet("locked_apps", new HashSet<>());
        Set<String> updatedStringSet = new HashSet<>(stringSet);
        SharedPreferences.Editor editor = preferences.edit();
        packageName = getIntent().getStringExtra("packageName");

        if (savedPasscode.equals(userEnteredPasscode)) {
            Log.e("From External App", "checkPasscode: is Correct");
            Log.e(TAG, "LOCKED APPS: "+updatedStringSet);
            Log.e(TAG, "PACKAGE NAME: "+packageName);
            // Store the result in SharedPreferences
            editor.putBoolean(packageName, true);
            updatedStringSet.remove(packageName);
            Log.e(TAG, "UPDATED LOCKED APPS: "+updatedStringSet);
            editor.putStringSet("locked_apps", updatedStringSet);
            editor.putBoolean(packageName+"_isRunning", false);
            editor.apply();
            DocumentReference docRef = db.collection("Children").document(childName);
            Map<String, Object> updates = new HashMap<>();
            List<String> updatedStringList = new ArrayList<>(updatedStringSet);
            Log.e(TAG, "Updated Locked Apps for FIRESTORE: "+updatedStringList);
            updates.put("locked_apps", updatedStringList);
//            updates.put(packageName, true);
            Log.e(TAG, "fields to update: "+updates);
            try {
                docRef.update(updates)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Log.d(TAG, "Fields updated successfully");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e(TAG, "Error updating fields in Firestore", e);
                            }
                        });
            } catch (Exception e) {
                Log.e(TAG, "Exception during Firestore update: " + e.getMessage());
            }
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            PackageManager packageManager = getPackageManager();
            Intent launchIntent = packageManager.getLaunchIntentForPackage(packageName);
            startActivity(launchIntent);
        } else {
            // Display an error message (e.g., incorrect passcode)
            Toast.makeText(this, "Incorrect passcode. Please try again.", Toast.LENGTH_SHORT).show();
        }

    }
}

