package com.example.applocker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button startParent;
    private Button startChild;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity);
        startParent = findViewById(R.id.startButtonParent);
        startChild = findViewById(R.id.startButtonChild);
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        startParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, HomePageParent.class);
                Bundle args = new Bundle();
                args.putString("i_am", "parent");
                InstalledAppsFragment fragment = new InstalledAppsFragment();
                fragment.setArguments(args);
//                Intent intent = new Intent(MainActivity.this, InstalledAppsActivity.class);
                editor.putString("i_am", "parent").apply();
                intent.putExtras(args);
                startActivity(intent);
            }
        });

        startChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EnterChildName.class);
                editor.putString("i_am", "child").apply();
                startActivity(intent);
                finish();
            }
        });
    }
}
