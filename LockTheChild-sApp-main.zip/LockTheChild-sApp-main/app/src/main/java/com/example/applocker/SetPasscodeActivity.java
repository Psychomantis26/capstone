package com.example.applocker;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SetPasscodeActivity extends AppCompatActivity {
    private EditText passcodeEditText;
    private EditText childNameText;
    private EditText timerEditText;

    private LinearLayout restrictionLayout;

    private EditText restrictionText;
    private Button setLimitButton;
    private Button setPhoneLock;
//    private Button showTimerButton;
    private String TAG = "App Locker on Security Set";
    private TextInputLayout childNameLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // ...

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_passcode);
        setLimitButton = findViewById(R.id.setTimeButton);
        setPhoneLock = findViewById(R.id.restrictButton);
        childNameLayout = findViewById(R.id.passcodeNameLayout);
        passcodeEditText = findViewById(R.id.passcodeEditText);
        restrictionLayout = findViewById(R.id.restrictionLayout);
        restrictionText = findViewById(R.id.restrictionText);
        childNameText = findViewById(R.id.passcodeNameText);
        timerEditText = findViewById(R.id.timerEditText);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        Intent intent = getIntent();
        ArrayList<PackageInfo> selectedAppsList = intent.getParcelableArrayListExtra("selectedApps");
        timerEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action needed before text changes.
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // No action needed when the text is changing.
            }

            @Override
            public void afterTextChanged(Editable s) {
                String timerValue = s.toString();
                if (!timerValue.isEmpty()) {
                    restrictionLayout.setVisibility(View.VISIBLE);
                } else {
                    restrictionLayout.setVisibility(View.GONE);
                }
            }
        });



        setPhoneLock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String passcode = passcodeEditText.getText().toString();

                Log.e(TAG, "onClick: "+passcode);
                String packageName = getIntent().getStringExtra("packageName");
                // Store the passcode
                if(passcode.isEmpty() | childNameText.getText().toString().isEmpty())
                {
                    showFailSnackbar(view);

                }else{
                    storePasscode(selectedAppsList, passcode, 0);
                    showSuccessSnackbar(view);
                }

            }
        });

        setLimitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String passcode = passcodeEditText.getText().toString();
                String timer = timerEditText.getText().toString();
                String restrictionTime = restrictionText.getText().toString();
//                String packageName = getIntent().getStringExtra("packageName");

                // Store the passcode
                if(restrictionTime.isEmpty()){
                    if(passcode.isEmpty() | timer.isEmpty() | childNameText.getText().toString().isEmpty()){
                        showFailSnackbar(view);
                    }else{

                        storePasscode(selectedAppsList, passcode, 0);
                        showSuccessSnackbar(view);
                    }
                }else{
                    storePasscode(selectedAppsList, passcode, 1);
                    showSuccessSnackbar(view);
                }



            }
        });


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // Handle the back button action here
                // For example, you can close the current activity
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void storePasscode(ArrayList<PackageInfo> selectedApps, String passcode, Integer isLock) {
        Log.d("TAG", "Store Passcode");
        String childName = childNameText.getText().toString().toLowerCase().trim();
        // Use SharedPreferences to store the passcode
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        String timerValue = timerEditText.getText().toString().isEmpty() ? "0" : timerEditText.getText().toString();
        String restrictionTime = isLock == 0 ? "0" : restrictionText.getText().toString();

        editor.apply();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        List<String> lockedApps = new ArrayList<>();
//        lockedApps.add(packageName);
        Map<String, Object> data = new HashMap<>();
        for (PackageInfo app : selectedApps) {
            String selected = app.packageName;
            lockedApps.add(selected);
            data.put(selected, false);
        }
        data.put("name", childName);
        data.put("timeStamp", FieldValue.serverTimestamp());
        data.put("isUsingRestrictionTime", Integer.parseInt(restrictionTime));
        data.put("is_using_timer", !timerValue.equals("0"));
        data.put("parent_device", android.os.Build.MODEL+"_"+android.os.Build.ID);
        data.put("passcode", passcode);
        data.put("timer", Integer.parseInt(timerValue));
        data.put("locked_apps", lockedApps);

        db.collection("Children")
                .document(childName)
                .set(data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d(TAG, "DocumentSnapshot successfully written!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });
    }

    private void showSuccessSnackbar(View view) {
        Snackbar.make(view, "Passcode set successfully!", Snackbar.LENGTH_SHORT).show();
        finish();
    }

    private void showFailSnackbar(View view) {
        Snackbar.make(view, "Please fill the fields!", Snackbar.LENGTH_SHORT).show();
    }
}

