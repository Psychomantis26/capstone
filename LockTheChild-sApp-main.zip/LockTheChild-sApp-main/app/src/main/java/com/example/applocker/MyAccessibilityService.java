package com.example.applocker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;

import android.content.Intent;
import android.content.SharedPreferences;

import android.content.pm.PackageManager;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import java.util.ArrayList;
import java.util.Set;


public class MyAccessibilityService extends AccessibilityService {
    private static final String TAG = "App Locker on AccessiblityService";

    @Override

    public void onAccessibilityEvent(AccessibilityEvent event) {
        SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
        String i_am = preferences.getString("i_am", "parent");
        Set<String> lockedAppsSet = preferences.getStringSet("locked_apps", null);
        ArrayList<String> lockedApps;

        if (lockedAppsSet == null) {
            lockedApps = new ArrayList<>();
            lockedApps.add("dummyValue"); // Add a dummy value
        } else {
            lockedApps = new ArrayList<>(lockedAppsSet);
        }


        if(event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED){
            boolean appIsRunning = preferences.getBoolean(event.getPackageName().toString()+"_isRunning", false);
            boolean isAppUnlocked = preferences.getBoolean(event.getPackageName().toString()+"_isLocked", false);
            boolean isRestricted = preferences.getBoolean(event.getPackageName().toString()+"_isRestricted", false);
            Long restrictCountdown = preferences.getLong("restrictCountdown", 0);

            Log.e(TAG, "RUNNING: "+event.getPackageName().toString()+"_isRunning");
            Log.e(TAG, "IS APP RUNNING?: "+appIsRunning);
            Log.e(TAG, "IS APP UNLOCKED: "+isAppUnlocked);
            Log.e(TAG, "ALL LOCKED APPS: "+lockedApps);
            if(i_am.equals("child")){
//                if(isAppUnlocked){
//                    Log.e(TAG, "--------------------------");
//                    if(isRestricted){
//                        Log.e(TAG, "UNLOCKED: RESTRICTED");
//                        Intent intent = new Intent(this, AppCheckPasscode.class);
//                        intent.putExtra("packageName", event.getPackageName().toString());
//                        intent.putExtra("restrictCountdown", restrictCountdown);
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                        startActivity(intent);
//
//                    }else{
//                        Log.e(TAG, "UNLOCKED: NOT RESTRICTED");
//                        PackageManager packageManager = getPackageManager();
//                        Intent launchIntent = packageManager.getLaunchIntentForPackage(event.getPackageName().toString());
//                        startActivity(launchIntent);
//                    }
//                }else{
//                    if(appIsRunning){
//                        PackageManager packageManager = getPackageManager();
//                        Intent launchIntent = packageManager.getLaunchIntentForPackage(event.getPackageName().toString());
//                        startActivity(launchIntent);
//                    }else{
//                        Log.e(TAG, "APP IS LOCKED");
//                        Log.e(TAG, "--------------------------");
//                        Log.e(TAG, "LOCKED");
//                        Intent intent = new Intent(this, AppCheckPasscode.class);
//                        intent.putExtra("packageName", event.getPackageName().toString());
//                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                        startActivity(intent);
//                    }
//
//
//                }
                if(lockedApps.contains(event.getPackageName().toString())){
                    if(appIsRunning){
                        PackageManager packageManager = getPackageManager();
                        Intent launchIntent = packageManager.getLaunchIntentForPackage(event.getPackageName().toString());
                        startActivity(launchIntent);
                    }else{
                        Intent intent = new Intent(this, AppCheckPasscode.class);
                        intent.putExtra("packageName", event.getPackageName().toString());
                        intent.putExtra("restrictCountdown", restrictCountdown);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                }
            }


        }

    }

    @Override
    public void onInterrupt() {
        Log.e(TAG,"Something went wrong!");
    }

    @Override
    protected void onServiceConnected(){
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        // Set the type of events that this service wants to listen to. Others
        // won't be passed to this service.
        info.eventTypes = AccessibilityEvent.TYPE_VIEW_CLICKED |
                AccessibilityEvent.TYPE_VIEW_FOCUSED | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;

        // If you only want this service to work with specific applications, set their
        // package names here. Otherwise, when the service is activated, it will listen
        // to events from all applications.


        // Set the type of feedback your service will provide.
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN;


        info.notificationTimeout = 100;

        this.setServiceInfo(info);
    }

}