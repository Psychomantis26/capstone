package com.example.applocker;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Parcelable;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;


public class InstalledAppsFragment extends Fragment {
    private List<PackageInfo> installedApps;
    private TextView titleTextView;
    private String iAm;

    private FloatingActionButton setPasscodeButton;
    private String TAG = "AppLocker InstallAppsFragment";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_installed_apps, container, false);

        // Initialize and populate the content of InstalledAppsActivity here
        titleTextView = view.findViewById(R.id.titleTextView);
        setPasscodeButton = view.findViewById(R.id.setPasscodeButton);
        if (getArguments() != null) {
            iAm = getArguments().getString("i_am");
            ArrayList<String> lockedApps = getArguments().getStringArrayList("locked_apps");
            String passcode = getArguments().getString("passcode");
            boolean isOpen = isAccessibilitySettingsOn(getContext());

            Log.e(TAG, "onCreate: "+isOpen);
            if(!isOpen){
                requestAccessibilityPermission();
            }

            installedApps = getInstalledApps();

            AppListAdapter adapter = new AppListAdapter(getContext(), R.layout.app_list_item, installedApps, iAm, lockedApps, null);

            ListView listView = view.findViewById(R.id.listView);
            listView.setAdapter(adapter);


            // Handle item clicks


            if (iAm != null && iAm.equals("child")) {
                titleTextView.setVisibility(View.GONE);
                setPasscodeButton.setVisibility(View.GONE);
                SharedPreferences.Editor editor = getActivity().getSharedPreferences("Passcodes", Context.MODE_PRIVATE).edit();
                for(String packageName:lockedApps){
                    editor.putString(packageName, passcode);
                    editor.putBoolean(packageName, false);
                }
                editor.apply();
            }else{
                setPasscodeButton.setVisibility(View.VISIBLE);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        // Toggle the selection of the clicked item
                        adapter.toggleSelection(position);
                    }
                });
                setPasscodeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        List<PackageInfo> selectedApps = adapter.getSelectedApps();
                        if (!selectedApps.isEmpty()) {
                            System.out.println(selectedApps);
                            // Start SetPasscodeActivity and pass the list of selected apps
                            Intent intent = new Intent(getContext(), SetPasscodeActivity.class);
                            intent.putParcelableArrayListExtra("selectedApps", (ArrayList<? extends Parcelable>) selectedApps);
                            startActivity(intent);
                        }
                    }
                });
            }
        }else{
            Log.e(TAG, "args is empty!");
        }

        return view;
    }

    private void requestAccessibilityPermission() {
        Intent intent = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);

    }


    public List<PackageInfo> getInstalledApps() {
        PackageManager pm = getContext().getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(0);
        List<PackageInfo> installedApps = new ArrayList<>();

        for (PackageInfo packageInfo : packages) {
            // Check if it's not a system app (user-installed app)
            if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                installedApps.add(packageInfo);
            }
        }

        // Sort the list by application name
        Collections.sort(installedApps, new Comparator<PackageInfo>() {
            @Override
            public int compare(PackageInfo packageInfo1, PackageInfo packageInfo2) {
                String appName1 = pm.getApplicationLabel(packageInfo1.applicationInfo).toString();
                String appName2 = pm.getApplicationLabel(packageInfo2.applicationInfo).toString();
                return appName1.compareToIgnoreCase(appName2);
            }
        });

        return installedApps;
    }

    // To check if service is enabled
    private boolean isAccessibilitySettingsOn(Context mContext) {
        int accessibilityEnabled = 0;
        final String service = getContext().getPackageName() + "/" + MyAccessibilityService.class.getCanonicalName();
        try {
            accessibilityEnabled = Settings.Secure.getInt(
                    mContext.getApplicationContext().getContentResolver(),
                    android.provider.Settings.Secure.ACCESSIBILITY_ENABLED);
            Log.v(TAG, "accessibilityEnabled = " + accessibilityEnabled);
        } catch (Settings.SettingNotFoundException e) {
            Log.e(TAG, "Error finding setting, default accessibility to not found: "
                    + e.getMessage());
        }
        TextUtils.SimpleStringSplitter mStringColonSplitter = new TextUtils.SimpleStringSplitter(':');

        if (accessibilityEnabled == 1) {
            Log.v(TAG, "***ACCESSIBILITY IS ENABLED*** -----------------");
            String settingValue = Settings.Secure.getString(
                    mContext.getApplicationContext().getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (settingValue != null) {
                mStringColonSplitter.setString(settingValue);
                while (mStringColonSplitter.hasNext()) {
                    String accessibilityService = mStringColonSplitter.next();

                    Log.v(TAG, "-------------- > accessibilityService :: " + accessibilityService + " " + service);
                    if (accessibilityService.equalsIgnoreCase(service)) {
                        Log.v(TAG, "We've found the correct setting - accessibility is switched on!");
                        return true;
                    }
                }
            }
        } else {
            Log.v(TAG, "***ACCESSIBILITY IS DISABLED***");
        }

        return false;
    }
}


