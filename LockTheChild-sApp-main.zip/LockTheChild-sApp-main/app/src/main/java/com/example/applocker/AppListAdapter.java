package com.example.applocker;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

public class AppListAdapter extends ArrayAdapter<PackageInfo> {
    private final List<PackageInfo> packageList;
    private final Context context;
    private final String iAm;
    private final String childName;
    private final List<String> lockedApps; // Added parameter
    private final List<Integer> selectedItems; // Keep track of selected items

    public AppListAdapter(Context context, int resource, List<PackageInfo> packageList, String iAm,
                          List<String> lockedApps, @Nullable String childName) {
        super(context, resource, packageList);
        this.context = context;
        this.packageList = packageList;
        this.childName = childName;
        this.iAm = iAm;
        this.lockedApps = lockedApps; // Initialize lockedApps
        this.selectedItems = new ArrayList<>();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.app_list_item, null);
        }

        PackageInfo packageInfo = packageList.get(position);

        if (packageInfo != null) {
            TextView appName = view.findViewById(R.id.appName);
            ImageView appIcon = view.findViewById(R.id.appIcon);
            TextView name = view.findViewById(R.id.name);
            if (appName != null) {
                appName.setText(context.getPackageManager().getApplicationLabel(packageInfo.applicationInfo));
            }

            if (name != null) {
                name.setText(childName);
            }

            if (appIcon != null) {
                appIcon.setImageDrawable(context.getPackageManager().getApplicationIcon(packageInfo.applicationInfo));
            }

            // Check if iAm is "child" and set background color
            if (iAm != null && iAm.equals("child")) {
                // Check if the current app is in the locked apps list and set background color
                if (lockedApps != null && lockedApps.contains(packageInfo.packageName)) {
                    view.setBackgroundColor(Color.rgb(217,217,217));
                } else {
                    view.setBackgroundColor(Color.TRANSPARENT);
                }
            }else{
                // Check if the item is selected and update the view accordingly
                if (selectedItems.contains(position)) {
                    view.setBackgroundColor(Color.rgb(217, 217, 217));
                } else {
                    view.setBackgroundColor(Color.TRANSPARENT);
                }
            }
        }



        return view;
    }
    // Method to toggle item selection
    public void toggleSelection(int position) {
        if (selectedItems.contains(position)) {
            selectedItems.remove(Integer.valueOf(position));
        } else {
            selectedItems.add(position);
        }
        notifyDataSetChanged();
    }

    // Method to clear all selections
    public void clearSelections() {
        selectedItems.clear();
        notifyDataSetChanged();
    }

    // Method to get a list of selected apps
    public List<PackageInfo> getSelectedApps() {
        List<PackageInfo> selectedApps = new ArrayList<>();
        for (int position : selectedItems) {
            selectedApps.add(packageList.get(position));
        }
        return selectedApps;
    }


}
