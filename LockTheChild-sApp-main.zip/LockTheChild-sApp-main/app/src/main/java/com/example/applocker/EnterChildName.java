package com.example.applocker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class EnterChildName extends AppCompatActivity {

    private Button submitButton;
    private EditText childName;
    private String TAG = "Firebase Firestore (Read DATA)";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_child_name);
        submitButton = findViewById(R.id.submitChildNameButton);
        childName = findViewById(R.id.nameEditText);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                if(!TextUtils.isEmpty(childName.getText().toString().trim())){
                    db.collection("Children")
                            .document(childName.getText().toString().toLowerCase().trim())
                            .get()
                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot document = task.getResult();
                                        ArrayList<String> lockedApps = new ArrayList<>();
                                        if (document.exists()) {
                                            showSuccessSnackbar(view);
                                            Log.d(TAG, "DocumentSnapshot data: " + document.getData());
                                            SharedPreferences preferences = getSharedPreferences("Passcodes", MODE_PRIVATE);
                                            SharedPreferences.Editor editor = preferences.edit();
                                            Object lockedAppsValue = document.get("locked_apps");
                                            if (lockedAppsValue instanceof ArrayList) {
                                                lockedApps = (ArrayList<String>) lockedAppsValue;
                                            }
//                                            ArrayList<String> lockedApps = (ArrayList<String>) document.get("locked_apps");
                                            editor.putString("child_name", childName.getText().toString().toLowerCase().trim()).apply();
                                            Set<String> lockedAppsSet = new HashSet<>(lockedApps);
                                            Log.e(TAG, "LockedAppSet: "+lockedAppsSet );
                                            editor.putStringSet("locked_apps", lockedAppsSet).apply();
                                            Intent intent = new Intent(EnterChildName.this, InstalledAppsActivity.class);
                                            intent.putExtra("i_am", "child");
                                            intent.putStringArrayListExtra("locked_apps", lockedApps);
                                            intent.putExtra("passcode", document.get("passcode").toString());
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            showSFailSnackbar(view);
                                            Log.d(TAG, "No such document");
                                        }
                                    } else {
                                        Log.d(TAG, "get failed with ", task.getException());
                                    }
                                }
                            });
                }else{
                    showSFailSnackbar(view);
                }


            }
        });
    }
    private void showSuccessSnackbar(View view) {
        Snackbar.make(view, "Fetching data...", Snackbar.LENGTH_SHORT).show();
    }

    private void showSFailSnackbar(View view) {
        Snackbar.make(view, "Name not registered!", Snackbar.LENGTH_SHORT).show();
    }
}