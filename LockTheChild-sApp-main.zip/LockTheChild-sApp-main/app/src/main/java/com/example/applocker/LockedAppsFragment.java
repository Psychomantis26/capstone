package com.example.applocker;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class LockedAppsFragment extends Fragment {
    private List<String> lockedAppsList;
    private List<PackageInfo> installedApps;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_locked_apps, container, false);
        Button button = view.findViewById(R.id.setPasscodeButton);
        button.setVisibility(View.GONE);
        lockedAppsList = new ArrayList<>();
        // Initialize Firebase Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Replace "childName" with the actual child's name
        String parentDevice = android.os.Build.MODEL+"_"+android.os.Build.ID;

        Query query = db.collection("Children").whereEqualTo("parent_device", parentDevice);

        query.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        // Check if the document has the 'locked_apps' field
                        if (document.contains("locked_apps")) {
                            String childName = (String) document.get("name");
                            Log.e("Name name name: ", childName);
                            Object lockedAppsValue = document.get("locked_apps");
                            if (lockedAppsValue instanceof List<?>) {
                                List<String> lockedApps = (List<String>) lockedAppsValue;
                                Log.e("LockedAppsFragment", "apps: " + lockedApps);
                                lockedAppsList.addAll(lockedApps);
                            } else {
                                Log.e("LockedAppsFragment", "The 'locked_apps' field is not a list.");
                                // Handle this case as needed.
                            }
                        } else {
                            Log.e("LockedAppsFragment", "The 'locked_apps' field does not exist in the document.");
                            // Create an empty list
                            List<String> emptyList = new ArrayList<>();
                            lockedAppsList.addAll(emptyList);
                        }
                        installedApps = getInstalledApps(lockedAppsList);
                        AppListAdapter adapter = new AppListAdapter(getContext(), R.layout.app_list_item, installedApps, "parent", lockedAppsList, null);
                        ListView listView = view.findViewById(R.id.listView);
                        listView.setAdapter(adapter);
                    }
                }
                else {
                    Log.d("LockedAppsFragment", "Error getting documents: ", task.getException());
                }
            }
        });






        return view;
    }

    public List<PackageInfo> getInstalledApps(List<String> lockedApps) {
        PackageManager pm = getContext().getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(0);
        List<PackageInfo> installedApps = new ArrayList<>();

        for (PackageInfo packageInfo : packages) {
            // Check if it's not a system app (user-installed app)
            if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                // Check if the app's package name is in the list of locked apps
                if (lockedApps.contains(packageInfo.packageName)) {
                    // Add the app to the list of installed apps
                    installedApps.add(packageInfo);
                }
            }
        }

        // Sort the list by application name
        Collections.sort(installedApps, new Comparator<PackageInfo>() {
            @Override
            public int compare(PackageInfo packageInfo1, PackageInfo packageInfo2) {
                String appName1 = pm.getApplicationLabel(packageInfo1.applicationInfo).toString();
                String appName2 = pm.getApplicationLabel(packageInfo2.applicationInfo).toString();
                return appName1.compareToIgnoreCase(appName2);
            }
        });

        return installedApps;
    }
}


