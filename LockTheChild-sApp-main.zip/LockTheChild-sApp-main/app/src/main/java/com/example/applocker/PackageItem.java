package com.example.applocker;

import android.graphics.drawable.Drawable;

import java.util.List;

public class PackageItem {

    private Drawable icon;

    private String name;

    private String packageName;

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Drawable getIcon() {
        return icon;
    }

    public void setIcon(Drawable icon) {
        this.icon = icon;
    }
//    public List<PackageItem> getInstalledApplication(){
//        PackageManager appInfo = getPackageManager();
//        List<ApplicationInfo> listInfo = appInfo.getInstalledApplications(0);
//        Collections.sort(listInfo, new ApplicationInfo.DisplayNameComparator(appInfo));
//
//        List<PackageItem> data = new ArrayList<PackageItem>();
//
//        for (int index = 0; index < listInfo.size(); index++) {
//            try {
//                ApplicationInfo content = listInfo.get(index);
//                if ((content.flags != ApplicationInfo.FLAG_SYSTEM) && content.enabled) {
//                    if (content.icon != 0) {
//                        PackageItem item = new PackageItem();
//                        item.setName(getPackageManager().getApplicationLabel(content).toString());
//                        item.setPackageName(content.packageName);
//                        item.setIcon(getPackageManager().getDrawable(content.packageName, content.icon, content));
//                        data.add(item);
//                    }
//                }
//            } catch (Exception e) {
//
//            }
//        }
//        return data;
//
//    }
}
