package com.example.applocker;

import android.app.ActionBar;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class HomePageParent extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_page_parent);

        ViewPager2 viewPager = findViewById(R.id.pageViewer);
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Retrieve the "i_am" value from your SharedPreferences or any other source
        SharedPreferences preferences = getSharedPreferences("Your_Preferences_Name", MODE_PRIVATE);
        String iAm = preferences.getString("i_am", "default_value_if_not_found");

        // Create a FragmentStateAdapter and connect it to the ViewPager2
        FragmentStateAdapter adapter = new MyFragmentStateAdapter(this, iAm);
        viewPager.setAdapter(adapter);

        // Connect the TabLayout to the ViewPager2
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> {
            if (position == 0) {
                tab.setText("Installed Apps");
            } else if (position == 1) {
                tab.setText("Locked Apps");
            }
        }).attach();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                // Handle the back button action here
                // For example, you can close the current activity
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}


class MyFragmentStateAdapter extends FragmentStateAdapter {
    private String iAm;

    public MyFragmentStateAdapter(@NonNull FragmentActivity fragmentActivity, String iAm) {
        super(fragmentActivity);
        this.iAm = iAm;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0) {
            Bundle args = new Bundle();
            args.putString("i_am", iAm);
            InstalledAppsFragment fragment = new InstalledAppsFragment();
            fragment.setArguments(args);
            return fragment;
        } else {
            // Create and pass arguments to LockedAppsFragment if needed
            return new LockedAppsFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 2; // Two tabs
    }
}

